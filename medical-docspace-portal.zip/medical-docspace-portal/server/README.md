# Server stubs

This folder contains minimal Express-style placeholders for DocSpace integration.
Wire these routes to the DocSpace REST API when turning the sample into a real app.
